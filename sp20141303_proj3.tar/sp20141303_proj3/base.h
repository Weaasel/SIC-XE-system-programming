#include "error.h"
#include <string.h>
#include <stdlib.h>

int char_to_hex(char c);
int str_to_hex(char* str);
int char_to_int(char c);
int str_to_int(char* str);
