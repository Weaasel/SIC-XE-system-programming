#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "shell.h"

//sicsim> argument
char arg[ARG_LEN];	

